var a = require('./zadanie_3_a');

console.log( a(17) );
